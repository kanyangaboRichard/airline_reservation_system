package com.airlinereservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
