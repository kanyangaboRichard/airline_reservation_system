package com.airlinereservation.dto;

import lombok.Data;

@Data
public class UserStatusUpdateRequestDto { 
	
	private int userId;
	
	private String status;

	public UserStatusUpdateRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserStatusUpdateRequestDto(int userId, String status) {
		super();
		this.userId = userId;
		this.status = status;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
