package com.airlinereservation.dto;

import lombok.Data;

@Data
public class FlightSeatDetailsResponse extends CommonApiResponse {

	private int totalSeat;

	private int economySeats;

	private int businessSeats;

	private int firstClassSeats;

	private int economySeatsAvailable;

	private int businessSeatsAvailable;

	private int firstClassSeatsAvailable;
	
	private int economySeatsWaiting;

	private int businessSeatsWaiting;

	private int firstClassSeatsWaiting;

	public FlightSeatDetailsResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightSeatDetailsResponse(String responseMessage, boolean isSuccess) {
		super(responseMessage, isSuccess);
		// TODO Auto-generated constructor stub
	}

	public FlightSeatDetailsResponse(int totalSeat, int economySeats, int businessSeats, int firstClassSeats,
			int economySeatsAvailable, int businessSeatsAvailable, int firstClassSeatsAvailable,
			int economySeatsWaiting, int businessSeatsWaiting, int firstClassSeatsWaiting) {
		super();
		this.totalSeat = totalSeat;
		this.economySeats = economySeats;
		this.businessSeats = businessSeats;
		this.firstClassSeats = firstClassSeats;
		this.economySeatsAvailable = economySeatsAvailable;
		this.businessSeatsAvailable = businessSeatsAvailable;
		this.firstClassSeatsAvailable = firstClassSeatsAvailable;
		this.economySeatsWaiting = economySeatsWaiting;
		this.businessSeatsWaiting = businessSeatsWaiting;
		this.firstClassSeatsWaiting = firstClassSeatsWaiting;
	}

	public int getTotalSeat() {
		return totalSeat;
	}

	public void setTotalSeat(int totalSeat) {
		this.totalSeat = totalSeat;
	}

	public int getEconomySeats() {
		return economySeats;
	}

	public void setEconomySeats(int economySeats) {
		this.economySeats = economySeats;
	}

	public int getBusinessSeats() {
		return businessSeats;
	}

	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}

	public int getFirstClassSeats() {
		return firstClassSeats;
	}

	public void setFirstClassSeats(int firstClassSeats) {
		this.firstClassSeats = firstClassSeats;
	}

	public int getEconomySeatsAvailable() {
		return economySeatsAvailable;
	}

	public void setEconomySeatsAvailable(int economySeatsAvailable) {
		this.economySeatsAvailable = economySeatsAvailable;
	}

	public int getBusinessSeatsAvailable() {
		return businessSeatsAvailable;
	}

	public void setBusinessSeatsAvailable(int businessSeatsAvailable) {
		this.businessSeatsAvailable = businessSeatsAvailable;
	}

	public int getFirstClassSeatsAvailable() {
		return firstClassSeatsAvailable;
	}

	public void setFirstClassSeatsAvailable(int firstClassSeatsAvailable) {
		this.firstClassSeatsAvailable = firstClassSeatsAvailable;
	}

	public int getEconomySeatsWaiting() {
		return economySeatsWaiting;
	}

	public void setEconomySeatsWaiting(int economySeatsWaiting) {
		this.economySeatsWaiting = economySeatsWaiting;
	}

	public int getBusinessSeatsWaiting() {
		return businessSeatsWaiting;
	}

	public void setBusinessSeatsWaiting(int businessSeatsWaiting) {
		this.businessSeatsWaiting = businessSeatsWaiting;
	}

	public int getFirstClassSeatsWaiting() {
		return firstClassSeatsWaiting;
	}

	public void setFirstClassSeatsWaiting(int firstClassSeatsWaiting) {
		this.firstClassSeatsWaiting = firstClassSeatsWaiting;
	}

}
