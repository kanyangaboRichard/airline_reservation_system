package com.airlinereservation.dto;

import lombok.Data;

@Data
public class FlightUpdateStatusRequestDto {
	
	private int flightId;
	
	private String status;

	public FlightUpdateStatusRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightUpdateStatusRequestDto(int flightId, String status) {
		super();
		this.flightId = flightId;
		this.status = status;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
