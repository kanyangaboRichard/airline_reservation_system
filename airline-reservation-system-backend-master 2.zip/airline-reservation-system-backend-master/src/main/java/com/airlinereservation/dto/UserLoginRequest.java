package com.airlinereservation.dto;

import lombok.Data;

@Data
public class UserLoginRequest {

	public UserLoginRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String emailId;

	private String password;

	private String role;

	public UserLoginRequest(String emailId, String password, String role) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.role = role;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
