package com.airlinereservation.dto;

import java.util.ArrayList;
import java.util.List;

import com.airlinereservation.entity.Airport;

import lombok.Data;

@Data
public class AirportResponseDto extends CommonApiResponse {

	private List<Airport> airports = new ArrayList<>();

	public AirportResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AirportResponseDto(String responseMessage, boolean isSuccess) {
		super(responseMessage, isSuccess);
		// TODO Auto-generated constructor stub
	}

	public AirportResponseDto(List<Airport> airports) {
		super();
		this.airports = airports;
	}

	public List<Airport> getAirports() {
		return airports;
	}

	public void setAirports(List<Airport> airports) {
		this.airports = airports;
	}
	
	
}
