package com.airlinereservation.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AddWalletMoneyRequestDto {
	
	private int userId;
	
	private double  walletAmount;

	public AddWalletMoneyRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddWalletMoneyRequestDto(int userId, double walletAmount) {
		super();
		this.userId = userId;
		this.walletAmount = walletAmount;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public double getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(double walletAmount) {
		this.walletAmount = walletAmount;
	}

}
