package com.airlinereservation.dto;

import java.util.ArrayList;
import java.util.List;

import com.airlinereservation.entity.FlightBooking;

import lombok.Data;

@Data
public class FlightBookingResponseDto extends CommonApiResponse {
	
	private List<FlightBooking> bookings = new ArrayList<>();

	public FlightBookingResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightBookingResponseDto(String responseMessage, boolean isSuccess) {
		super(responseMessage, isSuccess);
		// TODO Auto-generated constructor stub
	}

	public FlightBookingResponseDto(List<FlightBooking> bookings) {
		super();
		this.bookings = bookings;
	}

	public List<FlightBooking> getBookings() {
		return bookings;
	}

	public void setBookings(List<FlightBooking> bookings) {
		this.bookings = bookings;
	}

}
